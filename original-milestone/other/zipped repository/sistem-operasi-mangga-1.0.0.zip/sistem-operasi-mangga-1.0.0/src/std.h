// 13519214 - Standard function header

int strlen(char* string);
// Standard string length

int mod(int a, int n);
// Standard modulo function
