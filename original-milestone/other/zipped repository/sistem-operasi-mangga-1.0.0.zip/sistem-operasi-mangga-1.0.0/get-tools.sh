# 13519214 - Script for getting compiler and other tools
# Note : Use "chmod +x" if script failed to run
sudo apt update;
sudo apt install nasm bcc bin86 bochs bochs-x make;
