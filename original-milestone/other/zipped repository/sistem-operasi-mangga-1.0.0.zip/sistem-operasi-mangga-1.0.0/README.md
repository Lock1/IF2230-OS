# Tugas Besar - Sistem Operasi - IF2230
**TBA**

## Kelompok Mangga K04 :
   --Gregorius Dimas Baskara 13519190
   --Christian Gunawan 13519199
   --Tanur Rizaldi Rahardjo 13519214
   
   
<!-- ALSA - Vcxsrv -
- Bochs troubleshoot,
chmod +x troubleshoot
Dependencies
ALSA - Vcxsrv - Ubuntu 20.04 - <TBA>
- xserver
https://medium.com/javarevisited/using-wsl-2-with-x-server-linux-on-windows-a372263533c3
https://www.stat.ipb.ac.id/agusms/index.php/2019/01/15/how-to-run-graphical-linux-applications-on-bash-on-ubuntu-on-windows-10/
- ALSA
https://bbs.archlinux.org/viewtopic.php?id=94696
-->
