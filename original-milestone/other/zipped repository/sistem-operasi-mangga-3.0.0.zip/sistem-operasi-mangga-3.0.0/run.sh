# 13519214 - Run OS on sudo mode

sudo bochs -f src/if2230.config
