// 13519214 - Basic operation

int div(int a, int b);

int mod(int a, int n);
