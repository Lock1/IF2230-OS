// 13519214 - Simple macro for boolean
#define bool char
#define false 0
#define true 1
